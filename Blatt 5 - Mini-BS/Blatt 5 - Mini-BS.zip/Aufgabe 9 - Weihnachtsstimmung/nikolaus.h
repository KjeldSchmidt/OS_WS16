void randomOutputColor();
void changeOutputColor( int code );
char replaceColorCharWithNothingAndChangeColorOfTerminalOutput( char );
void loadTree();
void printTreeLine();
